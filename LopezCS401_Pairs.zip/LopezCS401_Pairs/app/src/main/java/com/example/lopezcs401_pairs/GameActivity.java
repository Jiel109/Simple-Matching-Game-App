package com.example.lopezcs401_pairs;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class GameActivity extends AppCompatActivity {
    ImageView currentView = null;
    private int count = 0;
    final int[] drawable = new int[]
            {
                    R.drawable.hokusai, R.drawable.bootao,
                    R.drawable.hutao, R.drawable.melusine, R.drawable.morgan,
                    R.drawable.toto
            };

    int[] pos = {2, 0, 3, 1, 5, 4, 0, 2, 3, 1, 4, 5};
    int currentPos = -1;
    private Handler handler = new Handler();
    private GridView gridView;
    private ImageAdapter imageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_game);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            ImageButton buttonHome = findViewById(R.id.buttonHome);
            GridView gridView = (GridView) findViewById(R.id.gridView);

            gridView.setHorizontalSpacing(1);
            gridView.setVerticalSpacing(30);

            buttonHome.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(GameActivity.this, MainActivity.class);
                    startActivity(intent);
                }

            });
            ImageAdapter imageAdapter = new ImageAdapter(this);
            gridView.setAdapter(imageAdapter);
            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (currentPos<0)
                    {
                        currentPos = position;
                        currentView = (ImageView)view;
                        ((ImageView)view).setImageResource(drawable[pos[position]]);
                    }
                    else
                    {
                        if(currentPos == position)
                        {
                            ((ImageView)view).setImageResource(R.drawable.sq);
                        }
                        else if(pos[currentPos]!=pos[position]) {
                            ((ImageView) view).setImageResource(drawable[pos[position]]);
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    currentView.setImageResource(R.drawable.sq);
                                    ((ImageView) view).setImageResource(R.drawable.sq);
                                    Toast.makeText(getApplicationContext(), "Incorrect pair!", Toast.LENGTH_SHORT).show();
                                }
                            }, 1000);
                        }
                        else
                        {
                            ((ImageView)view).setImageResource(drawable[pos[position]]);
                            Toast.makeText(getApplicationContext(), "Correct pair!",Toast.LENGTH_SHORT).show();
                            count++;

                            if(count==6)
                            {
                                Toast.makeText(getApplicationContext(), "You guessed all pairs correctly!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        currentPos = -1;
                    }
                }
            });
            return insets;

        });

    }
}